Geplante Trajektorien fuer den Pinterguss (Datensatz 2026_08_17_Pinterguss)
============================================================================
Erstellt: 2026-08-19, FAU (L. Schneider) — Planung auf Basis des circular_1200-Scans
vom 2026-08-17 (Geometrie aus dessen EZRT-Headern, FOD 996.6 mm / FDD 1995.4 mm).

Inhalt
------
planned_trajectory_pinterguss_bundle_z2000/   Objective "bundle" (Coverage + Absorptions-Penalty)
planned_trajectory_pinterguss_all3_z2000/     Objective "all3"   (Coverage + VCL + Absorptions-Penalty)
  je N0050/ N0100/ N0200/ N0300/ N0400/       Trajektorien mit 50/100/200/300/400 Views
    trajectory_coords.csv                     view, theta_deg, phi_deg, src_x_mm, src_y_mm, src_z_mm
    trajectory_headers.txt                    ein Block pro View mit AGV-Feldern
  trajectory_overview.png                     theta/phi-Uebersicht aller Budgets

Konventionen — identisch zum Kamera-Export vom 2026-07-16
---------------------------------------------------------
- agv_source_position_m / agv_detector_center_position_m: METER, Isozentrums-zentriert
  (Isozentrum wie im circular_1200-Scan vom 2026-08-17).
- agv_detector_line_direction / agv_detector_col_direction: Einheitsvektoren,
  gleiche Vorzeichenkonvention wie in den Headern eurer Messungen.
- Quellpositionen liegen auf der Kugel FOD=996.6 mm, Band 360 Grad Azimut x +-30 Grad
  Elevation (Envelope-Limit wie beim Kamera-Experiment beruecksichtigt).
- Detektor zeigt durchs Isozentrum, FDD 1995.4 mm.

Bitte messen (wie beim Kamera-Experiment)
-----------------------------------------
1) bundle  N0100  (100 Views)
2) bundle  N0400  (400 Views)
3) all3    N0100  (100 Views)
4) all3    N0400  (400 Views)
Die uebrigen Budgets (N0050/N0200/N0300) sind optional, falls Kapazitaet da ist.
Roehreneinstellungen gerne wie beim circular_1200-Scan des Pintergusses.

WICHTIG: Bitte das Objekt seit dem circular_1200-Scan vom 2026-08-17 nicht umspannen
bzw. falls doch, kurzen Prescan mitschicken. Anmerkung: Im circular-Scan ragte der
Sockel/die Einspannung unten aus dem Sichtfeld — fuer die geplanten Scans ist das ok
(gleiches FOV wie bisher verwenden).

Rueckfragen: linda-sophie.schneider@fau.de
